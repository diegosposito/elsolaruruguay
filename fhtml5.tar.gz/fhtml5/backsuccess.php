<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
    box-sizing: border-box;
}

input[type=text], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    resize: vertical;
}

label {
    padding: 12px 12px 12px 0;
    display: inline-block;
}

input[type=submit] {
    background-color: #793a72;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.header img {
    width: 100%;
    height: 200px;
}

.container {
    border-radius: 5px;
    
    background-image:url('fondo.jpg'); 
    padding: 20px;
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit] {
        width: 100%;
        margin-top: 0;
    }
}
</style>
</head>
<body>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "172.18.0.2";
$userName = "root";
$password = "root911";
$dbName = "bd_elsolar";

$codigo_jornada='J1COD';

$con = mysqli_connect($host, $userName, $password,$dbName);

if (mysqli_connect_errno())
  {
  echo "Falló la conexión a la base de datos: " . mysqli_connect_error();
  }


if(isset($_POST)){
        $sql = "INSERT INTO jornadas (apellido,nombre,dni,email,telefono,profesion,localidad,observaciones,codigojornada,created_at,updated_at,importe,esta_pago)
        VALUES ('".$_POST["apellido"]."','".$_POST["nombre"]."','".$_POST["dni"]."','".$_POST["email"]."','".$_POST["telefono"]."','".$_POST["profesion"]."','".$_POST["localidad"]."','".$_POST["detalles"]."','".$codigo_jornada."', now(), now(), 0, 0)";

if (!mysqli_query($con,$sql))

  {

  die('Error: ' . mysqli_error($con));

  }

}

mysqli_close($con);

?>

<div class="header"><img src="http://www.elsolaruruguay.com.ar:8082/header.jpg" alt="" /></a></div>


<div class="container">
  <form action="index.php" method="post" action="post">
    <div class="row">
      <div class="col-25">
        <label for="success1"></label>
      </div>
      <div class="col-50">
        <label for="success"><b>Ha sido registrado/a al curso correctamente!!</b></label>
      </div>
    </div>
    
    <div class="row">
      <input type="submit" value="Volver">
    </div>
  </form>
</div>

</body>
</html>

