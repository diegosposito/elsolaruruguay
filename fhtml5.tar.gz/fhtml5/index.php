<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
    box-sizing: border-box;
}

input[type=text], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    resize: vertical;
}

label {
    padding: 12px 12px 12px 0;
    display: inline-block;
}

input[type=submit] {
    background-color: #793a72;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.header img {
    width: 100%;
    height: 200px;
}

.container {
    border-radius: 5px;
    
    background-image:url('fondo.jpg'); 
    padding: 20px;
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit] {
        width: 100%;
        margin-top: 0;
    }
}
</style>
</head>
<body>

<div class="header"><img src="http://www.elsolaruruguay.com.ar:8082/header.jpg" alt="" /></a></div>


<div class="container">
  <form action="success.php" method="post" action="post">
    <div class="row">
      <div class="col-25">
        <label for="apellido">Apellido(*)</label>
      </div>
      <div class="col-75">
        <input type="text" id="apellido" name="apellido" required="required" pattern="[A-Za-z0-9]{1,50}" placeholder="Debe ingresar su apellido..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="nombre">Nombre(*)</label>
      </div>
      <div class="col-75">
        <input type="text" id="nombre" name="nombre" required="required" pattern="[A-Za-z0-9]{1,50}" placeholder="Debe ingresar su nombre..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="nombre">D.N.I.(*)</label>
      </div>
      <div class="col-75">
        <input type="text" id="dni" name="dni" required="required" pattern="[.0-9]{1,50}" placeholder="Debe ingresar su D.N.I.">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="nombre">Email(*)</label>
      </div>
      <div class="col-75">
        <input type="email" id="email" name="email" required="required" placeholder="Debe ingresar su email..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="nombre">Teléfono(*)</label>
      </div>
      <div class="col-75">
        <input type="text" id="telefono" name="telefono" required="required" placeholder="Debe ingresar su teléfono..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="nombre">Profesión(*)</label>
      </div>
      <div class="col-75">
        <input type="text" id="profesion" name="profesion" required="required" pattern="[A-Za-z0-9]{1,50}" placeholder="Debe ingresar su Profesión..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="nombre">Localidad(*)</label>
      </div>
      <div class="col-75">
        <input type="text" id="localidad" name="localidad" required="required" placeholder="Debe ingresar su Localidad..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="subject">Observaciones</label>
      </div>
      <div class="col-75">
        <textarea id="detalles" name="detalles" placeholder="Puede escribir algo que desee aclarar.." style="height:200px"></textarea>
      </div>
    </div>
    <div class="row">
      <div class="col-50">
        <label for="nombre">Datos obligatorios (*)</label><br>
        <label for="nombre"><b>COSTO DE INSCRIPCIÓN $500</b></label>
<label>La inscripción se hará efectiva cuando se acredite el pago.</label>
<label><b>Personalmente en Alem 120, Concepción del Uruguay</b>  de lunes a viernes de 8 a 14 horas</label>

<label><b>Por transferencia bancaria o depósito</b>: Banco Patagonia - Sucursal 306, Cuenta Corriente en pesos Nº 306 – 30600 9808 000, CBU 0340306600306009808002, El Solar Uruguay – Asociación Civil, CUIT 30-71437762-7. Cuando se utilice esta modalidad de pago enviar comprobante a administración@elsolaruruguay.com.ar</label>

      </div>
    </div>
    <!--
    <div class="row">
      <div class="col-25">
        <label for="country">Country</label>
      </div>
      <div class="col-75">
        <select id="country" name="country">
          <option value="australia">Australia</option>
          <option value="canada">Canada</option>
          <option value="usa">USA</option>
        </select>
      </div>
    </div>
-->
    
    <div class="row">
      <input type="submit" value="Registrarse">
    </div>
  </form>
</div>

</body>
</html>

